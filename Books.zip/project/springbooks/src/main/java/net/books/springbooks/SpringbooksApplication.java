package net.books.springbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbooksApplication.class, args);
	}

}
