package net.books.springbooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
