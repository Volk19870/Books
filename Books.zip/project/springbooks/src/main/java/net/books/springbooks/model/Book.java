package net.books.springbooks.model;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@Entity
@Table (name = "books")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String Author;
    private String Book;
    private java.sql.Date Date;
    @Column(name = "Quant_page")
    private Integer Quantpage;
    private BigDecimal Price;
    @Column(name = "Quant_inst")
    private Integer Quantinst;
}